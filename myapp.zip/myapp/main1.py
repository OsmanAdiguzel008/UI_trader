# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 16:48:02 2022

@author: oadiguzel
"""

from PyQt5.QtWidgets import QMainWindow, QApplication, QMenuBar, QMdiArea, QLineEdit
from PyQt5.QtWidgets import QMdiSubWindow, QTextEdit, QDialog, QMenuBar, QWidget
from PyQt5.QtCore import QTimer
from PyQt5 import uic
import sys, time, os
import rsi
import securityinfo, historicaltable, pricegraphic


class UI(QMainWindow):
    count = 0
    opening_window = None
    sm = None
    args = {}
    
    def __init__(self):
        super(UI, self).__init__()
        
        # Load th ui file
        uic.loadUi("ui\main.ui", self)
        
        # Define olur widgets on Menu
        self.mdi = self.findChild(QMdiArea, "mdiArea")
        self.menu = self.findChild(QMenuBar, "menubar")
        
        # Click Button
        self.new_window.triggered.connect(self.open_select_menu)
        
        self.testaction.triggered.connect(self.add_window)
        
        self.menu = self.menuBar()
        self.menu.addAction('Add',self.add_window)
        self.menu.addAction('?',self.is_secure)
        #self.menu.addAction('args',self.update)
        self.main_windows()
        
        # This work but disgard during updates
    #    # QTimer
    #    self._interval = int(10*1000)
    #    self.timer = QTimer()
    #    self.timer.timeout.connect(self.update)
    #    self.timer.start(self._interval)
        
        # Show The App
        self.show()
    
    
    def update(self):
        
        setattr(self.args["historicaltable"], 
                "ticker",
                self.args["securityinfo"].ticker)
        setattr(self.args["pricegraphic"],
                "ticker",
                self.args["securityinfo"].ticker)
        print(self.args["pricegraphic"].period)
        print(self.args["pricegraphic"].interval)
        setattr(self.args["historicaltable"], 
                "period",
                self.args["pricegraphic"].period)
        setattr(self.args["historicaltable"], 
                "interval",
                self.args["pricegraphic"].interval)
        
        
        self.related_updates()
        
        self.args["historicaltable"].companyname.setText(
            self.args["securityinfo"].row.name.values[0])
    
    def related_updates(self):
        self.args["securityinfo"].update()
        self.args["pricegraphic"].update()
        self.args["historicaltable"].update()
        
    def main_windows(self):
        for i in [["historicaltable","DataTable"],
                  ["securityinfo","SecurityInfo"],
                  ["pricegraphic","MplGraph"]]:
            self.opening_window = i
            self.add_window()
        
    def is_secure(self):
        si = SecurityIssue()
        self.addWidget(si)
        self.setCurrentIndex(self.currentIndex() + 1)
        
    
    def open_select_menu(self):
        self.sm = SelectMenu()
        self.sm.show()
        
    def add_window(self):
        UI.count = UI.count + 1
        # import module
        # Create Sub Window
        sub = QMdiSubWindow()
        # Do stuff in the sub windows
        x = self.opening_window
        try:
            print(x)
            sub.setWidget(eval(f"{x[0]}.{x[1]}()"))
        except NameError:
            raise Exception("There is no such menu in your list")
        # Set The Titlebar or the Sub Window
        sub.setWindowTitle(x[1])
        # Add The Sub Window Into Our MDI Widget
        self.mdi.addSubWindow(sub)
        
        # Show the new sub window
        sub.show()
        
        ### Position the sub windows
        
        # tile them
        self.mdi.tileSubWindows()
        
        # Cascade them
        #self.mdi.cascadeSubWindows()
        
        # Do more some stuffs
        #self.mdi.closeActiveSubWindow()
        #self.mdi.removeSubWindow()
        #self.mdi.subWindowList()
        
        self.args[x[0]] = sub.widget()
    
        
class SelectMenu(QDialog):
    
    menus = {"Table Menu": ["historicaltable","DataTable"],
             "Security Information Menu": ["securityinfo","SecurityInfo"],
             "Graphics Menu": ["priceegraphic","MplGraph"],
             "Data Table Menu":"a",
             "Portfolio Menu":"b",
             "Security Info Menu":"c", 
             "RSI Menu":"RSI"
                }
    
    def __init__(self):
        
        self.result = None
        super(SelectMenu, self).__init__()
        uic.loadUi("ui\selectmenu.ui", self)
        
        self.setWindowTitle("Menu Selection")
        
        self.droplist.addItems(self.menus.keys())
        
        self.cancelbutton.clicked.connect(self.cancelbutton_)
        self.okbutton.clicked.connect(self.okbutton_)
        
    def okbutton_(self):
        menu = self.droplist.currentText()
        menumap = self.menus[menu]
        setattr(UI,"opening_window", menumap)
        print(f"{menumap}")
        self.close()
    
    def cancelbutton_(self):
        print("Canceling...")
        self.close()
        
        
class SecurityIssue(QDialog):
    def __init__(self,widget=None):
        super(SecurityIssue, self).__init__()
        uic.loadUi("ui/security_issue.ui", self)
        
        self.count = 0
        self.passwordfield.setEchoMode(QLineEdit.Password)
        self.pushButton.clicked.connect(self.buttonaction)
        
    def buttonaction(self):
        if self.count < 3:
            try:
                password = self.passwordfield.text()
                validate(password)
                ts = TradeScreen()
                widget.addWidget(ts)
                widget.setCurrentIndex(widget.currentIndex() + 1)
            except NameError:
                self.error.setText("Please input valid password!")
                self.count += 1
                pass
        else:
            if os.path.isfile("credentials.txt"):
                os.remove("credentials.txt")
            self.close()
            
    
app = QApplication(sys.argv)
window = UI()
app.exec_()
