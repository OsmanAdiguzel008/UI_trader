
colours = { "table_row" : {"first" : (26,26,26) ,"second" : (51,51,51)},
            "table_header" : (136,156,56),
            "table__ch_color" : (255, 255, 255)
             }