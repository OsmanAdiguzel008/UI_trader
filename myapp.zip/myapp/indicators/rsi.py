# -*- coding: utf-8 -*-


import sys
from PyQt5.uic import loadUi
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDialog, QMainWindow, QApplication, QWidget
import talib as ta
import pandas as pd
import numpy as np

class RSI(QDialog):
    def __init__(self, price, canvas):
        
        self.result = None
        self.price = price
        self.canvas  = canvas
        super(RSI, self).__init__()
        
        loadUi( "C://myml/myapp/indicators/ui/rsi.ui", self)
        
        self.cancelbutton.clicked.connect(self.cancelbutton_)
        self.okbutton.clicked.connect(self.okbutton_)
        self.show()
        
    def okbutton_(self):
        
        pr = int(self.periodinput.text())
        lg = self.laginput.text()
        
        self.function_(period = pr)
        self.graph_()
        self.close()
    
    def cancelbutton_(self):
        print("Canceling...")
        self.close()
        
    def function_(self, period=14):
        if len(self.price.Close) == 0:
            return np.nan
        series = self.price.Close
        self.price["rsi"] = ta.RSI(series, period)
        
    def graph_(self, sub_plot=212):

        cl = self.colourinput.currentText()
        ls = self.linestyleinput.currentText()
        lw = float(self.linewidthinput.text())
        
        ub = int(self.upperbandinput.text())
        lb = int(self.lowerbandinput.text())
        
        self.canvas.axes = self.canvas.figure.add_subplot(sub_plot)
        self.canvas.axes.set_facecolor('black')
        self.canvas.axes.set_xlabel('time (s)', color='c')
        self.canvas.axes.set_ylabel('RSI', color='peachpuff')
        self.canvas.axes.tick_params(labelcolor='tab:orange')
        self.canvas.axes.spines['left'].set_color('grey')
        self.canvas.axes.spines['top'].set_color('grey') 
        self.canvas.axes.spines['right'].set_color('grey') 
        self.canvas.axes.spines['bottom'].set_color('grey') 
        
        self.canvas.axes.plot(self.price["rsi"], color=cl, linestyle=ls, linewidth=lw)
        self.canvas.axes.axhline(y=ub, color=cl, linestyle=ls, label="upperband")
        self.canvas.axes.axhline(y=lb, color=cl, linestyle=ls, label="lowerband")
        self.canvas.draw()
        
        


if __name__ == "__main__":
    
    app = QApplication(sys.argv)
    window = RSI()
    app.exec_()
    