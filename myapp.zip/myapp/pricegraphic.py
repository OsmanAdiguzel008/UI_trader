# -*- coding: utf-8 -*-
"""
Created on Thu Jun 30 14:42:33 2022

@author: oadiguzel
"""

from PyQt5.QtWidgets import *

from matplotlib.backends.backend_qt5agg import FigureCanvas

from matplotlib.figure import Figure
from PyQt5 import uic
import sys, time
from bist import bist100
from PyQt5.QtGui import QColor
from dict_ import colours
import numpy as np
import random
import importlib
import indicators


class MplGraph(QMainWindow):
    inputs = {"periods": ["1d","5d","1mo","3mo","6mo","1y","2y","5y","10y","ytd","max"],
             "intervals": ["1m","2m","5m","15m","30m","60m","90m","1h","1d","5d","1wk","1mo","3mo"]}
    
    period = None
    interval = None
    ticker = None
    
    linestyles = ["solid","dotted","dashed","dashdot"]
    colours = ["blue","green","red","cyan","magenta","yellow","black","white"]
    


    # key is droplist name and value is the file path and module name
    indicators = {"":"",
                  "Relative Strenght Index": ["rsi","RSI"],
                  }
    
    grafic_inputs = {}
    
    newadding_indicator = ""
    added_indicators = ["price"]
    
    def __init__(self):
        super(MplGraph, self).__init__()
        self.bist = bist100()
        
        # Load th ui file
        uic.loadUi("ui/mpl_window.ui", self)
        self.canvas = FigureCanvas(Figure(facecolor="black"))
        vertical_layout = QVBoxLayout(self.widgetmpl)
        vertical_layout.addWidget(self.canvas)
        
        
        self.indicatorsdroplist.addItems(self.indicators.keys())
        self.intervaldroplist.addItems(self.inputs["intervals"])
        self.perioddroplist.addItems(self.inputs["periods"])
        
     #   self.canvas_modify()
        self.setLayout(vertical_layout)
        # Show The App
        self.show()
        
        
    def price_canvas(self):
        x = self.subplot_size("price")
        self.canvas.axes = self.canvas.figure.add_subplot(x)
        self.canvas.axes.set_facecolor('black')
        self.canvas.axes.set_xlabel('time (s)', color='c')
        self.canvas.axes.set_ylabel("Price Data", color='peachpuff')
        self.canvas.axes.tick_params(labelcolor='tab:orange')
        self.canvas.axes.spines['left'].set_color('grey')
        self.canvas.axes.spines['top'].set_color('grey') 
        self.canvas.axes.spines['right'].set_color('grey') 
        self.canvas.axes.spines['bottom'].set_color('grey')
        
        close = self.price.Close
        self.canvas.axes.clear()
        self.canvas.axes.plot(close, color="blue")
        self.canvas.axes.legend(self.ticker,loc='upper left')
        self.canvas.axes.set_title(f'{self.ticker} Price Chart', color='0.7')
        
        
    
    def update(self):
        if self.ticker != None:
            self.new_indicator()
            self.tickerlabel2.setText(self.ticker)
            self.period   = self.perioddroplist.currentText()
            self.interval = self.intervaldroplist.currentText()
            print("-"*50,self.ticker)
            self.price = self.bist.get_price(self.ticker,
                                             period=self.period,
                                             interval=self.interval)
            self.price = self.price.sort_index(ascending=True).reset_index()
            self.price_canvas()
            self.canvas.draw()
    
        
    def new_indicator(self):
        if self.newadding_indicator != self.indicatorsdroplist.currentText():
            print("Appending new indicators")
            self.added_indicators.append(self.indicatorsdroplist.currentText())
            print(self.indicatorsdroplist.currentText())
            self.newadding_indicator = self.indicatorsdroplist.currentText()
            ind = self.indicatorsdroplist.currentText()
            pth1, pth2 = self.indicators[ind]
            module = importlib.import_module(f"indicators.{pth1}")
            self.obj = getattr(module, f"{pth2}")(self.price,self.canvas)
            self.obj.colourinput.addItems(self.colours)
            self.obj.linestyleinput.addItems(self.linestyles)
            self.obj.show()
            self.grafic_inputs[pth1] = self.obj
            
            
    def draw_lines(self):
        self.obj.colourinput.addItems(self.colours)
        self.obj.linestyleinput.addItems(self.linestyles)
        setattr(self.obj,"price",self.price)
        self.obj.function_()
        self.obj.graph_(self.canvas.axes, )
        
    def subplot_size(self,element):
        row = len(self.added_indicators)
        q = self.added_indicators.index(element) + 1
        return int(f"{row}1{q}")

    def open_select_menu(self):
        self.sm = SelectMenu()
        self.sm.show()
        

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MplGraph()
    app.exec_()
    
