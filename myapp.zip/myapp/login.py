# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 18:49:11 2022

@author: oadiguzel
"""

import sys
from PyQt5.uic import loadUi
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDialog, QMainWindow, QApplication, QWidget

class LoginScreen(QDialog):
    
    is_logedin = False
    
    def __init__(self):
        super(LoginScreen, self).__init__()
        loadUi("ui/login.ui", self)
        self.passwordfield.setEchoMode(QtWidgets.QLineEdit.Password)
        self.loginbutton.clicked.connect(self.loginfunction)
        self.newaccountbutton.clicked.connect(self.newaccountform)
      
    
    def loginfunction(self):
        user = self.usernamefield.text()
        password = self.passwordfield.text()
        
        if (len(user)  == 0) | (len(password) == 0):
            self.error.setText("Please input all fields")
            
        else:
            f = open("credentials.txt", "r")
            cre = {}
            for x in f:
                cre[x.split(",")[3]] = x.split(",")[4].strip('\n')
            if user not in cre.keys():
                self.error.setText("Invalid username")
            else:
                if cre[user] != password:
                    self.error.setText("Invalid password")
                else:
                    self.is_logedin = True
                    self.trade_screen()
                    print("Successfully logged in")
    

    def trade_screen(self):
        if self.is_logedin == True:
            from main import UI
            ui = UI()
            widget.addWidget(ui)
            widget.setCurrentIndex(widget.currentIndex() + 1)
            
        
    def newaccountform(self):
        newaccpage = CreateAccountForm()
        widget.addWidget(newaccpage)
        widget.setCurrentIndex(widget.currentIndex() + 1)
        print("This is a new account form")
        
        

class CreateAccountForm(QDialog):
    def __init__(self):
        super(CreateAccountForm, self).__init__()
        loadUi("ui/createaccountform.ui", self)
       # self.setFixedHeight(650)
       # self.setFixedWidth(400)
        self.cancelbutton.clicked.connect(self.backtologinpage)
        self.createaccountbutton.clicked.connect(self.createaccount)
        
        self.passwordfield.setEchoMode(QtWidgets.QLineEdit.Password)
        self.passwordconfirmationfield.setEchoMode(QtWidgets.QLineEdit.Password)
        
    def createaccount(self):
        name = self.namefield.text()
        surname = self.surnamefield.text()
        email = self.emailfield.text()
        user = self.usernamefield.text()
        password = self.passwordfield.text()
        password_c =self.passwordconfirmationfield.text()
        try:
            f = open("credentials.txt", "r")
        except FileNotFoundError:
            message = """The error has occured because of wrong validation 
            please take a support further solution"""
            self.error.setText("Unknown Error!")
            raise Exception(message)
        cre = {}
        u = []
        em = []
        for x in f:
            u.append(x.split(",")[3])
            em.append(x.split(",")[2])
            cre[x.split(",")[3]] = x.split(",")[4].strip('\n')
        f.close()
        if (len(user)  == 0) | (len(password) == 0) | (len(name) == 0) | (
                len(surname) == 0) | (len(password_c) == 0) | (
                    len(email) == 0):
            self.error.setText("Please input all fields")
        else:
            if "@" not in email:
                self.error.setText("Please enter a valid e-mail")
            elif email in em:
                self.error.setText("This e-mail is already in use")
            elif user in u:
                self.error.setText("This username is already in use")
            elif password != password_c:
                self.error.setText("Passwords do not match")
            else:
                string = f"{name},{surname},{email},{user},{password}\n"
                f = open("credentials.txt", "a")
                f.write(string)
                f.close()
                self.backtologinpage()
        
    def backtologinpage(self):
        login = LoginScreen()
        widget.addWidget(login)
        widget.setCurrentIndex(widget.currentIndex() + 1)
        


# main
app = QApplication(sys.argv)
login = LoginScreen()
widget = QtWidgets.QStackedWidget()
widget.addWidget(login)
widget.show()

try:
    sys.exit(app.exec_())
except:
    print("Exiting")



  
  
  
