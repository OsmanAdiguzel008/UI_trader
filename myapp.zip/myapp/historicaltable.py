# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 16:20:37 2022

@author: oadiguzel
"""


from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5.QtWidgets import QTextEdit, QDialog, QTableWidgetItem
from PyQt5 import uic
import sys, time
from bist import bist100
from PyQt5.QtGui import QColor
from dict_ import colours


class DataTable(QDialog):
    count = 0
    sm = None
    args = {"ticker" : None}
    period = None
    interval = None
    ticker = None
    
    def __init__(self):
        super(DataTable, self).__init__()
        
        # Load th ui file
        uic.loadUi("ui/historicaltable.ui", self)
        
        self.bist = bist100()
        
        # Show The App
        self.show()

    def update(self):
        self.frame_update()
        self.remove_rows()
        self.add_table_rows()
        
    def frame_update(self):
        self.price = self.bist.get_price(self.ticker)
        
        
            
    def remove_rows(self):
        try:
            print("removing", len(self.price))
            print(self.table.rowCount())
            for i in range(self.table.rowCount()):
                self.table.removeRow(self.table.rowCount()-1)
        except:
            pass
        
    def add_table_rows(self):
        print("historicaltable: ",self.period,self.interval)
        if (self.period == None) | (self.interval == None):
            self.price = self.bist.get_price(self.ticker)
        else:
            self.price = self.bist.get_price(self.ticker, 
                                             period = self.period,
                                             interval = self.interval)
        self.price = self.price.sort_index(ascending=False).reset_index()
        print(len(self.price))
        self.row_count = len(self.price)
        #set table header
        cl = colours["table_header"]
        cl = QColor(cl[0],cl[1],cl[2])
        self.table.setColumnCount(len(self.price.columns))
        self.table.setHorizontalHeaderLabels(list(self.price.columns))
        for i in range(len(self.price.columns)):
            self.table.horizontalHeaderItem(i).setBackground(QColor(0,0,0))
            #self.table.horizontalHeaderItem(i).setForeground(QColor(255,255,255))

        cl_count = 0
        for i,r in self.price.iterrows():
            row_data = list(r)
            row_count = self.table.rowCount()
            self.table.setRowCount(row_count+1)
            col = 0
            for item in row_data:
                cell = QTableWidgetItem(str(item))
                self.table.setItem(row_count, col, cell)
                if cl_count % 2 == 0:
                    cl = colours["table_row"]["first"]
                else:
                    cl = colours["table_row"]["second"]
                cl = QColor(cl[0],cl[1],cl[2])
                self.table.item(row_count, col).setBackground(cl)
                cl2 = colours["table__ch_color"]
                cl2 = QColor(cl2[0],cl2[1],cl2[2])
                self.table.item(row_count, col).setForeground(cl2)
                col += 1
            cl_count += 1
        
    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = DataTable()
    app.exec_()