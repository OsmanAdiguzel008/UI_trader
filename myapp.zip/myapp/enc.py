# -*- coding: utf-8 -*-

from cryptography.fernet import Fernet
from zipfile import ZipFile
import os, time


def validate(ps):
    try:
        with ZipFile('enc.zip') as zf:
            zf.extractall(pwd=ps.encode())
        file = open("enc.txt","r")
        text = file.read()
        key,text = text.split(";")
        file.close()
        f = Fernet(key.encode())
        encripted = text.encode()
        message = f.decrypt(encripted).decode()
        remove_file("enc.txt")
    except:
        raise NameError("Invalid password, Please try again!")
    return print(message)

def remove_file(path):
    if os.path.isfile(path):
        os.remove(path)
        remove_file(path)
    else:
        pass
    

if __name__ == "__main__":
    validate()
