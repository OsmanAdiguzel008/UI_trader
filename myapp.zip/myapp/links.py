

web_links = {"components":"https://tr.wikipedia.org/wiki/Borsa_İstanbul"}