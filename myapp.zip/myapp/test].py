import matplotlib.pyplot as plt
fig = plt.figure()
fig.add_subplot(111)   #top left
fig.add_subplot(111)   #top right
#fig.add_subplot(223)   #bottom left
#fig.add_subplot(224)   #bottom right 
plt.show()

