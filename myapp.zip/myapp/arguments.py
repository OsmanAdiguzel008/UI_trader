# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 10:24:24 2022

@author: oadiguzel
"""

args = {"new_window" : None,
        "ticker" : None
        }