# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 11:36:00 2022

@author: oadiguzel
"""



from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5.QtWidgets import QTextEdit, QDialog
from PyQt5 import uic
import sys, time
from bist import bist100


class SecurityInfo(QDialog):
    count = 0
    opening_window = None
    sm = None
    args = {"ticker" : None}
    
    def __init__(self):
        super(SecurityInfo, self).__init__()
        
        # Load th ui file
        uic.loadUi("ui/securityinfo.ui", self)
        
        self.bist = bist100()
        
        # for the dropdown list
        self.droplist.addItems(self.bist.components.ticker.to_list())
        
        self.ticker = self.droplist.currentText()
    
        self.updatebutton.clicked.connect(self.update)
        self.closebutton.clicked.connect(self.test2)
        
        # Show The App
        self.show()

        
    def test2(self):
        pass
        
    def update(self):
        self.ticker = self.droplist.currentText()
        self.args["ticker"] = self.ticker
        self.row = self.bist.components[self.bist.components.ticker == self.ticker]
        self.namelabel2.setText(self.row.name.values[0])
        self.symbollabel2.setText(self.row.ticker.values[0])
        self.sectorlabel2.setText(self.row.sector.values[0])
        self.subsectorlabel2.setText(self.row.sub_sector.values[0])
        self.citylabel2.setText(self.row.city.values[0])
        self.datelabel2.setText(self.row.founding.values[0])
        # updating table values
    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = SecurityInfo()
    app.exec_()