# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 16:48:02 2022

@author: oadiguzel
"""

from PyQt5.QtWidgets import QMainWindow, QApplication, QMenuBar, QMdiArea, QLineEdit
from PyQt5.QtWidgets import QMdiSubWindow, QTextEdit, QDialog, QMenuBar, QWidget
from PyQt5.QtCore import QTimer
from enc import validate
from PyQt5 import uic
import sys, time, os
import securityinfo, historicaltable, pricegraphic
import datetime as  dt

class UI(QMainWindow):
    count = 0
    opening_window = None
    sm = None
    args = {}
    
    time_left_int  = 300
    time_left_int2 = 60
    is_activated = False
    
    time_mapping = {"1m":60,"2m":120,"5m":300}
    
    "1m,2m,5m,15m,30m,60m,90m,1h,1d,5d,1wk,1mo,3mo"
    
    need_update = True
    
    def __init__(self):
        super(UI, self).__init__()
        
        # Load th ui file
        uic.loadUi("ui\main.ui", self)
        
        # Define olur widgets on Menu
        self.mdi = self.findChild(QMdiArea, "mdiArea")
        self.menu = self.findChild(QMenuBar, "menubar")
        
        # Click Button
        self.new_window.triggered.connect(self.open_select_menu)
        
        self.testaction.triggered.connect(self.main_windows)
        
        self.menu = self.menuBar()
        self.menu.addAction('Add',self.add_window)
        self.menu.addAction('Manual Update',self.update)
        self.menu.addAction('Resize',self.mdi.tileSubWindows)
        self.menu.addAction('Activation',self.end_timer_timeout)
        self.timer_start()
        
        # This work but disgard during updates
        # QTimer
        self._interval = int(1000)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update)
        self.timer.start(self._interval)
        
        
        # QTimer2
        self._interval = int(0.5*1000)
        self.timer_dt = QTimer()
        self.timer_dt.timeout.connect(self.datetime_update)
        self.timer_dt.start(self._interval)
        
        
        
        # Show The App
        self.show()
            
    def datetime_update(self):
        value = dt.datetime.today().strftime("%b-%d-%Y  %H:%M:%S")
        self.currenttime.setText(value)
        
    
    def update(self): 
        
        if self.need_update == True:
            if len(self.args) == 0:
                self.main_windows()
                self.need_update = False
                
        self.control_update_conditions()
        
        
        if self.need_update == True:
            print(self.args)
            self.set_arguments()
            self.related_updates()
            
            self.args["historicaltable"].companyname.setText(
                self.args["securityinfo"].row.name.values[0])
            self.need_update = False
            
    def set_arguments(self):
        setattr(self.args["pricegraphic"],
                "ticker",
                self.args["securityinfo"].ticker)
        
        setattr(self.args["historicaltable"], 
                "ticker",
                self.args["securityinfo"].ticker)
        
        setattr(self.args["historicaltable"], 
                "period",
                self.args["pricegraphic"].period)
        
        setattr(self.args["historicaltable"], 
                "interval",
                self.args["pricegraphic"].interval)
        """
        setattr(self.args["historicaltable"], 
                "interval",
                self.args["pricegraphic"].interval)
        """
        
    def control_update_conditions(self):
        
        if int(dt.datetime.today().second) == 0:
            self.need_update = True
            pass
        
        if self.args["securityinfo"].droplist.currentText(
                                        ) != self.args["securityinfo"].ticker:
            self.need_update = True
            pass
            
        if self.args["pricegraphic"].perioddroplist.currentText(
                                        ) != self.args["pricegraphic"].period:
            self.need_update = True
            pass
            
        if self.args["pricegraphic"].intervaldroplist.currentText(
                                      ) != self.args["pricegraphic"].interval:
            self.need_update = True
            pass
        
        if self.args["pricegraphic"].ticker != self.args["securityinfo"].ticker:
            self.need_update = True
            pass
            
        if self.args["historicaltable"].period != self.args["pricegraphic"].period:
            self.need_update = True
            pass
            
        if self.args["historicaltable"].interval != self.args["pricegraphic"].interval:
            self.need_update = True
            pass
        
        if self.args["pricegraphic"].newadding_indicator != self.args["pricegraphic"].indicatorsdroplist.currentText():
            self.need_update = True
            pass
    
    def related_updates(self):
        self.args["securityinfo"].update()
        self.args["pricegraphic"].update()
        self.args["historicaltable"].update()
        
    def main_windows(self):
        for i in [["historicaltable","DataTable"],
                  ["securityinfo","SecurityInfo"],
                  ["pricegraphic","MplGraph"]]:
            self.opening_window = i
            self.add_window()
    
    def open_select_menu(self):
        self.sm = SelectMenu()
        self.sm.show()
        
    def add_window(self):
        UI.count = UI.count + 1
        # import module
        # Create Sub Window
        sub = QMdiSubWindow()
        # Do stuff in the sub windows
        x = self.opening_window
        print("open select menu: ",self.opening_window)
        try:
            sub.setWidget(eval(f"{x[0]}.{x[1]}()"))
        except NameError:
            raise Exception("There is no such menu in your list")
        # Set The Titlebar or the Sub Window
        sub.setWindowTitle(x[1])
        # Add The Sub Window Into Our MDI Widget
        self.mdi.addSubWindow(sub)
        
        # Show the new sub window
        sub.show()
        
        ### Position the sub windows
        
        # tile them
        self.mdi.tileSubWindows()
        
        # Cascade them
        #self.mdi.cascadeSubWindows()
        
        # Do more some stuffs
        #self.mdi.closeActiveSubWindow()
        #self.mdi.removeSubWindow()
        #self.mdi.subWindowList()
        
        self.args[x[0]] = sub.widget()
    
        
        

##############################################################################

    def timer_start(self):
        self.countdown = QTimer(self)
        self.countdown.timeout.connect(self.timer_timeout)
        self.countdown.start(1000)
        self.timer_down.setText(str(self.time_left_int))

    def timer_timeout(self):
        self.time_left_int -= 1
        self.timer_down.setText(str(self.time_left_int))
        if self.time_left_int == 0:
            self.activate_full_version()
            self.countdown.stop()
            
            self.countdown2 = QTimer(self)
            self.countdown2.timeout.connect(self.timer_timeout2)
            self.countdown2.start(1000)
            self.timer_down.setText(str(self.time_left_int))
            
    def end_timer_timeout(self):
        self.time_left_int = 3
        
    def timer_timeout2(self):
        self.time_left_int2 -= 1
        self.si.timer_down2.setText(str(self.time_left_int2))
        if self.si.is_activated == True:
            self.timer_down.setText("")
            self.version_info.setText("Full Version")
            self.is_activated = self.si.is_activated
        else:
            if self.time_left_int2 == 0:
                self.countdown2.stop()
                self.si.close()
                self.close()
                if os.path.isfile("credentials.txt"):
                    os.remove("credentials.txt")
            else:
                pass

    def activate_full_version(self):
        self.si = SecurityIssue()
        self.si.show()
        setattr(self, 
                "is_activated",
                self.si.is_activated)
        setattr(self, 
                "activation_count",
                self.si.count)
        if self.activation_count == 3:
            if self.is_activated == False:
                self.close()

##############################################################################



class SelectMenu(QDialog):
    
    menus = {"Table Menu": ["historicaltable","DataTable"],
             "Security Information Menu": ["securityinfo","SecurityInfo"],
             "Graphics Menu": ["pricegraphic","MplGraph"],
             "Data Table Menu":"a",
             "Portfolio Menu":"b",
             "Security Info Menu":"c", 
             "RSI Menu":"RSI"
                }
    menumap = None
    
    def __init__(self):
        
        self.result = None
        super(SelectMenu, self).__init__()
        uic.loadUi("ui\selectmenu.ui", self)
        
        self.setWindowTitle("Menu Selection")
        
        self.droplist.addItems(self.menus.keys())
        
        self.cancelbutton.clicked.connect(self.cancelbutton_)
        self.okbutton.clicked.connect(self.okbutton_)
        
    def okbutton_(self):
        menu = self.droplist.currentText()
        menumap = self.menus[menu]
        setattr(UI,"opening_window", menumap)
        self.close()
    
    def cancelbutton_(self):
        print("Canceling...")
        self.close()
        
        
class SecurityIssue(QDialog):
    
    is_activated = False
    count = 0
        
    def __init__(self,widget=None):
        super(SecurityIssue, self).__init__()
        uic.loadUi("ui/activation_window.ui", self)
        
        self.passwordfield.setEchoMode(QLineEdit.Password)
        self.pushButton.clicked.connect(self.buttonaction)
        
    def buttonaction(self):
        if self.count < 3:
            try:
                password = self.passwordfield.text()
                validate(password)
                self.is_activated = True
                self.close()
            except NameError:
                self.count += 1
                if self.count == 2:
                    self.error.setText("Last chance to activate the program. Please input valid password!")
                elif self.count == 3:
                    self.error.setText("You entered incorrectly three times")
                    
                    self.close()
                else:
                    self.error.setText("Please input valid password!")
                pass
        else:
            if os.path.isfile("credentials.txt"):
                os.remove("credentials.txt")
            self.close()
            

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = UI()
    app.exec_()
